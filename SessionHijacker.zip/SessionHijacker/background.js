// Service worker: listens for messages from popup
// Service worker: listens for messages from popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.action === "getCookies") {
        chrome.cookies.getAll({}, (cookies) => {
            const cookiesString = JSON.stringify(cookies, null, 2); // Format cookies
            sendResponse({ cookies: cookiesString });
        });
        return true; // Required to use asynchronous sendResponse
    }
});


// Function to copy text to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(
        () => console.log("Text successfully copied to clipboard."),
        (err) => console.error("Failed to copy text to clipboard.", err)
    );
}
