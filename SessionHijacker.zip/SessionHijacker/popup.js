document.getElementById("getCookies").addEventListener("click", () => {
    chrome.runtime.sendMessage({ action: "getCookies" }, (response) => {
        if (response && response.cookies) {
            // Copy the cookies to the clipboard
            copyToClipboard(response.cookies);

            // Notify the user
            alert("Cookies copied to clipboard!");
        } else {
            alert("Failed to get cookies.");
        }
    });
});

// Function to copy text to clipboard
function copyToClipboard(text) {
    navigator.clipboard.writeText(text).then(
        () => console.log("Cookies successfully copied to clipboard."),
        (err) => console.error("Failed to copy cookies to clipboard:", err)
    );
}

// Inject cookies from the input text area
document.getElementById("injectCookies").addEventListener("click", () => {
    const cookieData = document.getElementById("cookieInput").value;

    try {
        const cookies = JSON.parse(cookieData); // Parse the JSON input

        cookies.forEach((cookie) => {
            chrome.cookies.set({
                url: `https://${cookie.domain.replace(/^\./, '')}`, // Construct the URL for the cookie
                name: cookie.name,
                value: cookie.value,
                path: cookie.path || "/",
                secure: cookie.secure || false,
                httpOnly: cookie.httpOnly || false,
                sameSite: cookie.sameSite || "Lax",
                expirationDate: cookie.expirationDate || (Date.now() / 1000 + 3600), // 1-hour expiration if not provided
            }, (cookieSet) => {
                if (chrome.runtime.lastError) {
                    console.error("Failed to set cookie:", chrome.runtime.lastError);
                } else {
                    console.log("Cookie set:", cookieSet);
                }
            });
        });

        alert("Cookies injected successfully!");
    } catch (error) {
        console.error("Invalid cookie data:", error);
        alert("Failed to inject cookies. Please ensure the input is valid JSON.");
    }
});
